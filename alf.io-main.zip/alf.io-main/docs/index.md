### Documentation

#### How to...

- [Configure Apple(tm) Pass integration](howto/configuration/apple-pass/index.md)
- [Configure Stripe for Strong Customer Authentication](howto/configuration/stripe-sca/index.md)