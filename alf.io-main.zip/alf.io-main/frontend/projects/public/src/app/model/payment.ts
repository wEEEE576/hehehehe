export class TransactionInitializationToken {
    clientSecret: string;
    reservationStatusChanged: boolean;
}
