export interface LocalizedCountry {
    isoCode: string;
    name: string;
}
