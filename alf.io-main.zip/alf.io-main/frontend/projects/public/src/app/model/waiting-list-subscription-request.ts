export class WaitingListSubscriptionRequest {
    firstName: string;
    lastName: string;
    email: string;
    userLanguage: string;
    termAndConditionsAccepted: string;
    privacyPolicyAccepted: string;
    selectedCategory: string;
}
