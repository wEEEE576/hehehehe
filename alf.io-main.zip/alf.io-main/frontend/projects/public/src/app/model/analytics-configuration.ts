export class AnalyticsConfiguration {
    googleAnalyticsKey: string | null;
    googleAnalyticsScrambledInfo: boolean;
    clientId: string | null;
}
