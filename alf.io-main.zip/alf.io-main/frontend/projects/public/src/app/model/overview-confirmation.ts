export class OverviewConfirmation {
    termAndConditionsAccepted: boolean;
    privacyPolicyAccepted: boolean;
}
