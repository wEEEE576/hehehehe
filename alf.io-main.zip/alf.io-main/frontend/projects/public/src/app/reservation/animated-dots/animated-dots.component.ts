import {Component} from '@angular/core';

@Component({
    selector: 'app-animated-dots',
    template: '<span class="dots"><span>.</span><span>.</span><span>.</span></span>',
    styleUrls: ['./animated-dots.component.scss']
})
export class AnimatedDotsComponent {

}
