export class PollOption {
    id: number;
    pollId: number;
    title: {[key: string]: string};
    description: {[key: string]: string};
}