import {PollOption} from './poll-option';
import {Poll} from './poll';

export class PollWithOptions {
    poll: Poll;
    options: PollOption[];
}
